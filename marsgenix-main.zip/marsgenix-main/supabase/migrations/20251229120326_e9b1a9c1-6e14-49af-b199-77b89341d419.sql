-- Create app roles enum
CREATE TYPE public.app_role AS ENUM ('customer', 'helper', 'admin');

-- Create task status enum
CREATE TYPE public.task_status AS ENUM ('pending', 'accepted', 'in_progress', 'picked_up', 'delivered', 'completed', 'cancelled');

-- Create helper status enum
CREATE TYPE public.helper_status AS ENUM ('pending', 'approved', 'rejected', 'suspended');

-- Create document type enum
CREATE TYPE public.document_type AS ENUM ('id_proof', 'address_proof', 'photo', 'other');

-- Create profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  phone TEXT,
  avatar_url TEXT,
  address TEXT,
  city TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create user_roles table (separate for security)
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE (user_id, role)
);

-- Create task_categories table
CREATE TABLE public.task_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  base_price DECIMAL(10,2) DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create pricing_rules table
CREATE TABLE public.pricing_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id UUID REFERENCES public.task_categories(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  price_per_km DECIMAL(10,2) DEFAULT 5,
  base_price DECIMAL(10,2) DEFAULT 50,
  surge_multiplier DECIMAL(3,2) DEFAULT 1.0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create helper_profiles table
CREATE TABLE public.helper_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  status helper_status DEFAULT 'pending',
  is_online BOOLEAN DEFAULT false,
  is_available BOOLEAN DEFAULT true,
  rating DECIMAL(2,1) DEFAULT 0,
  total_tasks INTEGER DEFAULT 0,
  total_earnings DECIMAL(10,2) DEFAULT 0,
  verification_notes TEXT,
  verified_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create helper_documents table
CREATE TABLE public.helper_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  helper_id UUID REFERENCES public.helper_profiles(id) ON DELETE CASCADE NOT NULL,
  document_type document_type NOT NULL,
  document_url TEXT NOT NULL,
  is_verified BOOLEAN DEFAULT false,
  verified_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create tasks table
CREATE TABLE public.tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  helper_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  category_id UUID REFERENCES public.task_categories(id),
  title TEXT NOT NULL,
  description TEXT,
  status task_status DEFAULT 'pending',
  pickup_address TEXT NOT NULL,
  pickup_lat DECIMAL(10,8),
  pickup_lng DECIMAL(11,8),
  drop_address TEXT NOT NULL,
  drop_lat DECIMAL(10,8),
  drop_lng DECIMAL(11,8),
  distance_km DECIMAL(10,2),
  estimated_price DECIMAL(10,2),
  final_price DECIMAL(10,2),
  scheduled_at TIMESTAMP WITH TIME ZONE,
  accepted_at TIMESTAMP WITH TIME ZONE,
  picked_up_at TIMESTAMP WITH TIME ZONE,
  delivered_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  cancelled_at TIMESTAMP WITH TIME ZONE,
  cancel_reason TEXT,
  customer_rating INTEGER,
  helper_rating INTEGER,
  customer_review TEXT,
  helper_review TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create earnings table
CREATE TABLE public.earnings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  helper_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  task_id UUID REFERENCES public.tasks(id) ON DELETE CASCADE NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  commission DECIMAL(10,2) DEFAULT 0,
  net_amount DECIMAL(10,2) NOT NULL,
  status TEXT DEFAULT 'pending',
  paid_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create notifications table
CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT DEFAULT 'info',
  is_read BOOLEAN DEFAULT false,
  data JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.task_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pricing_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.helper_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.helper_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.earnings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Create security definer function to check roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- Create function to get user role
CREATE OR REPLACE FUNCTION public.get_user_role(_user_id UUID)
RETURNS app_role
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.user_roles WHERE user_id = _user_id LIMIT 1
$$;

-- Profiles policies
CREATE POLICY "Users can view own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "Admins can view all profiles" ON public.profiles
  FOR SELECT USING (public.has_role(auth.uid(), 'admin'));

-- User roles policies
CREATE POLICY "Users can view own roles" ON public.user_roles
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all roles" ON public.user_roles
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- Task categories policies (public read)
CREATE POLICY "Anyone can view active categories" ON public.task_categories
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage categories" ON public.task_categories
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- Pricing rules policies
CREATE POLICY "Anyone can view active pricing" ON public.pricing_rules
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage pricing" ON public.pricing_rules
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- Helper profiles policies
CREATE POLICY "Helpers can view own profile" ON public.helper_profiles
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Helpers can update own profile" ON public.helper_profiles
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Helpers can insert own profile" ON public.helper_profiles
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can manage all helper profiles" ON public.helper_profiles
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Customers can view approved helpers" ON public.helper_profiles
  FOR SELECT USING (status = 'approved');

-- Helper documents policies
CREATE POLICY "Helpers can manage own documents" ON public.helper_documents
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.helper_profiles hp WHERE hp.id = helper_id AND hp.user_id = auth.uid())
  );

CREATE POLICY "Admins can manage all documents" ON public.helper_documents
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- Tasks policies
CREATE POLICY "Customers can view own tasks" ON public.tasks
  FOR SELECT USING (auth.uid() = customer_id);

CREATE POLICY "Customers can create tasks" ON public.tasks
  FOR INSERT WITH CHECK (auth.uid() = customer_id);

CREATE POLICY "Customers can update own tasks" ON public.tasks
  FOR UPDATE USING (auth.uid() = customer_id);

CREATE POLICY "Helpers can view assigned tasks" ON public.tasks
  FOR SELECT USING (auth.uid() = helper_id);

CREATE POLICY "Helpers can view available tasks" ON public.tasks
  FOR SELECT USING (
    public.has_role(auth.uid(), 'helper') AND status = 'pending' AND helper_id IS NULL
  );

CREATE POLICY "Helpers can update assigned tasks" ON public.tasks
  FOR UPDATE USING (auth.uid() = helper_id);

CREATE POLICY "Admins can manage all tasks" ON public.tasks
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- Earnings policies
CREATE POLICY "Helpers can view own earnings" ON public.earnings
  FOR SELECT USING (auth.uid() = helper_id);

CREATE POLICY "Admins can manage earnings" ON public.earnings
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- Notifications policies
CREATE POLICY "Users can view own notifications" ON public.notifications
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notifications" ON public.notifications
  FOR UPDATE USING (auth.uid() = user_id);

-- Create function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_role app_role;
BEGIN
  -- Get role from metadata, default to 'customer'
  user_role := COALESCE(
    (NEW.raw_user_meta_data ->> 'role')::app_role,
    'customer'::app_role
  );
  
  -- Insert profile
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data ->> 'full_name');
  
  -- Insert role
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, user_role);
  
  -- If helper, create helper profile
  IF user_role = 'helper' THEN
    INSERT INTO public.helper_profiles (user_id)
    VALUES (NEW.id);
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger for new user signup
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create function to update updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

-- Create triggers for updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_helper_profiles_updated_at
  BEFORE UPDATE ON public.helper_profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_tasks_updated_at
  BEFORE UPDATE ON public.tasks
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_pricing_rules_updated_at
  BEFORE UPDATE ON public.pricing_rules
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- Insert default task categories
INSERT INTO public.task_categories (name, description, icon, base_price) VALUES
  ('Delivery', 'Package and parcel delivery', 'Package', 50),
  ('Grocery', 'Grocery shopping and delivery', 'ShoppingCart', 60),
  ('Documents', 'Document pickup and delivery', 'FileText', 40),
  ('Food', 'Food pickup and delivery', 'UtensilsCrossed', 45),
  ('Moving', 'Small item moving assistance', 'Truck', 150),
  ('Errands', 'General errands and tasks', 'CheckCircle', 75);

-- Insert default pricing rule
INSERT INTO public.pricing_rules (name, price_per_km, base_price, surge_multiplier) VALUES
  ('Standard', 5.00, 50.00, 1.0);

-- Enable realtime for tasks
ALTER PUBLICATION supabase_realtime ADD TABLE public.tasks;
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;