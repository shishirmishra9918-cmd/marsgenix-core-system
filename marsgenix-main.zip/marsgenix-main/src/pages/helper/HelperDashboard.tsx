import { useState } from "react";
import { HelperSidebar } from "@/components/layout/HelperSidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { 
  DollarSign, 
  Clock, 
  CheckCircle, 
  Star,
  MapPin,
  ArrowRight,
  ToggleLeft,
  Wallet,
  TrendingUp
} from "lucide-react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

const availableTasks = [
  {
    id: "1",
    title: "Grocery Pickup from DMart",
    category: "Shopping",
    distance: "2.5 km",
    price: 150,
    time: "30 min",
    customer: "Amit K."
  },
  {
    id: "2",
    title: "Document Delivery",
    category: "Delivery",
    distance: "1.8 km",
    price: 100,
    time: "20 min",
    customer: "Sneha R."
  },
  {
    id: "3",
    title: "Medicine Pickup",
    category: "Errands",
    distance: "3.2 km",
    price: 180,
    time: "45 min",
    customer: "Raj P."
  }
];

export default function HelperDashboard() {
  const [isOnline, setIsOnline] = useState(true);

  return (
    <div className="min-h-screen bg-background">
      <HelperSidebar />
      
      <main className="lg:pl-64">
        <div className="p-4 lg:p-8 pt-20 lg:pt-8">
          {/* Header with Online Toggle */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">Welcome, Rahul!</h1>
              <p className="text-muted-foreground">Here's your daily overview</p>
            </div>
            
            {/* Online/Offline Toggle */}
            <div className={cn(
              "flex items-center gap-4 p-4 rounded-xl border transition-colors",
              isOnline 
                ? "bg-success/10 border-success/30" 
                : "bg-secondary border-border"
            )}>
              <div className="flex items-center gap-3">
                <div className={cn(
                  "w-3 h-3 rounded-full",
                  isOnline ? "bg-success animate-pulse" : "bg-muted-foreground"
                )} />
                <span className="font-medium">
                  {isOnline ? "You're Online" : "You're Offline"}
                </span>
              </div>
              <Switch
                checked={isOnline}
                onCheckedChange={setIsOnline}
                className="data-[state=checked]:bg-success"
              />
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card className="hover:border-primary/50 transition-colors">
              <CardContent className="p-4 lg:p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Today's Earnings</p>
                    <p className="text-2xl lg:text-3xl font-bold">₹850</p>
                  </div>
                  <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-success/10 flex items-center justify-center">
                    <DollarSign className="h-5 w-5 lg:h-6 lg:w-6 text-success" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:border-primary/50 transition-colors">
              <CardContent className="p-4 lg:p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Tasks Completed</p>
                    <p className="text-2xl lg:text-3xl font-bold">5</p>
                  </div>
                  <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <CheckCircle className="h-5 w-5 lg:h-6 lg:w-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:border-warning/50 transition-colors">
              <CardContent className="p-4 lg:p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Active Hours</p>
                    <p className="text-2xl lg:text-3xl font-bold">4.5h</p>
                  </div>
                  <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-warning/10 flex items-center justify-center">
                    <Clock className="h-5 w-5 lg:h-6 lg:w-6 text-warning" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:border-primary/50 transition-colors">
              <CardContent className="p-4 lg:p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Rating</p>
                    <p className="text-2xl lg:text-3xl font-bold">4.9</p>
                  </div>
                  <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-warning/10 flex items-center justify-center">
                    <Star className="h-5 w-5 lg:h-6 lg:w-6 text-warning fill-warning" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Available Tasks */}
          {isOnline && (
            <Card className="mb-8">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Available Tasks Nearby</CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">Accept tasks to start earning</p>
                </div>
                <Button variant="ghost" asChild>
                  <Link to="/helper/tasks">
                    View all
                    <ArrowRight className="h-4 w-4 ml-1" />
                  </Link>
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {availableTasks.map((task) => (
                    <div 
                      key={task.id}
                      className="flex flex-col lg:flex-row lg:items-center justify-between p-4 rounded-xl bg-secondary/30 border border-border/50 hover:border-primary/30 transition-colors gap-4"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline">{task.category}</Badge>
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {task.distance}
                          </span>
                        </div>
                        <h3 className="font-medium mb-1">{task.title}</h3>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {task.time}
                          </span>
                          <span>by {task.customer}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <div className="text-lg font-bold text-success">₹{task.price}</div>
                          <div className="text-xs text-muted-foreground">Est. earnings</div>
                        </div>
                        <Button variant="hero" size="sm">
                          Accept
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Offline Message */}
          {!isOnline && (
            <Card className="mb-8 border-warning/30 bg-warning/5">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 rounded-full bg-warning/20 flex items-center justify-center mx-auto mb-4">
                  <ToggleLeft className="h-8 w-8 text-warning" />
                </div>
                <h3 className="text-xl font-semibold mb-2">You're currently offline</h3>
                <p className="text-muted-foreground mb-4">
                  Go online to start receiving task requests from customers nearby
                </p>
                <Button variant="warning" onClick={() => setIsOnline(true)}>
                  Go Online
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Weekly Stats */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wallet className="h-5 w-5 text-primary" />
                  Weekly Earnings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">₹4,250</div>
                <div className="flex items-center gap-2 text-sm">
                  <Badge variant="success" className="gap-1">
                    <TrendingUp className="h-3 w-3" />
                    +12%
                  </Badge>
                  <span className="text-muted-foreground">vs last week</span>
                </div>
                <div className="mt-6 space-y-3">
                  {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, i) => (
                    <div key={day} className="flex items-center gap-3">
                      <span className="w-10 text-sm text-muted-foreground">{day}</span>
                      <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-primary to-cyan-500 rounded-full"
                          style={{ width: `${[60, 80, 45, 90, 70, 100, 85][i]}%` }}
                        />
                      </div>
                      <span className="w-12 text-sm text-right">₹{[420, 560, 315, 630, 490, 700, 595][i]}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="h-5 w-5 text-warning" />
                  Performance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-muted-foreground">Acceptance Rate</span>
                      <span className="font-semibold">92%</span>
                    </div>
                    <div className="h-2 bg-secondary rounded-full overflow-hidden">
                      <div className="h-full bg-success rounded-full" style={{ width: '92%' }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-muted-foreground">Completion Rate</span>
                      <span className="font-semibold">98%</span>
                    </div>
                    <div className="h-2 bg-secondary rounded-full overflow-hidden">
                      <div className="h-full bg-primary rounded-full" style={{ width: '98%' }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-muted-foreground">On-time Delivery</span>
                      <span className="font-semibold">95%</span>
                    </div>
                    <div className="h-2 bg-secondary rounded-full overflow-hidden">
                      <div className="h-full bg-warning rounded-full" style={{ width: '95%' }} />
                    </div>
                  </div>
                  <div className="pt-4 border-t border-border">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">Total Tasks Completed</span>
                      <span className="text-2xl font-bold">127</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
