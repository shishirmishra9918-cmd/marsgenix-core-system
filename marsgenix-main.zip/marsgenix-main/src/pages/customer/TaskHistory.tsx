import { useState } from "react";
import { CustomerSidebar } from "@/components/layout/CustomerSidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Clock, 
  CheckCircle, 
  MapPin, 
  Search,
  Filter,
  Package,
  Truck,
  AlertCircle,
  XCircle,
  Calendar
} from "lucide-react";
import { useTasks } from "@/hooks/useTasks";
import { format } from "date-fns";

const statusConfig: Record<string, { label: string; variant: "default" | "warning" | "glow" | "success" | "destructive"; icon: any }> = {
  pending: { label: "Pending", variant: "warning", icon: Clock },
  accepted: { label: "Accepted", variant: "glow", icon: CheckCircle },
  in_progress: { label: "In Progress", variant: "glow", icon: Truck },
  picked_up: { label: "Picked Up", variant: "glow", icon: Package },
  delivered: { label: "Delivered", variant: "success", icon: CheckCircle },
  completed: { label: "Completed", variant: "success", icon: CheckCircle },
  cancelled: { label: "Cancelled", variant: "destructive", icon: XCircle }
};

export default function TaskHistory() {
  const { tasks, isLoading } = useTasks();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const filteredTasks = tasks.filter((task) => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.pickup_address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.drop_address.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || task.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-background">
      <CustomerSidebar />
      
      <main className="lg:pl-64">
        <div className="p-4 lg:p-8 pt-20 lg:pt-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-2xl md:text-3xl font-bold">Task History</h1>
            <p className="text-muted-foreground">View and track all your tasks</p>
          </div>

          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search tasks..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="accepted">Accepted</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Tasks List */}
          <Card>
            <CardHeader>
              <CardTitle>Your Tasks ({filteredTasks.length})</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
                </div>
              ) : filteredTasks.length === 0 ? (
                <div className="text-center py-12">
                  <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No tasks found</h3>
                  <p className="text-muted-foreground">
                    {searchQuery || statusFilter !== "all" 
                      ? "Try adjusting your filters" 
                      : "Create your first task to get started"}
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredTasks.map((task) => {
                    const status = statusConfig[task.status] || statusConfig.pending;
                    const StatusIcon = status.icon;
                    
                    return (
                      <div 
                        key={task.id}
                        className="flex flex-col lg:flex-row lg:items-center justify-between p-4 rounded-xl bg-secondary/30 border border-border/50 hover:border-primary/30 transition-colors gap-4"
                      >
                        <div className="flex items-start gap-4">
                          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                            <StatusIcon className="h-5 w-5 text-primary" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium truncate">{task.title}</h3>
                            <div className="flex flex-wrap items-center gap-2 mt-1 text-sm text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <Calendar className="h-3 w-3" />
                                {format(new Date(task.created_at), "MMM d, yyyy")}
                              </span>
                              {task.task_categories?.name && (
                                <>
                                  <span>•</span>
                                  <span>{task.task_categories.name}</span>
                                </>
                              )}
                              {task.estimated_price && (
                                <>
                                  <span>•</span>
                                  <span className="text-primary font-medium">₹{task.estimated_price}</span>
                                </>
                              )}
                            </div>
                            <div className="flex flex-col gap-1 mt-2 text-sm text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <MapPin className="h-3 w-3 text-primary" />
                                <span className="truncate">{task.pickup_address}</span>
                              </span>
                              <span className="flex items-center gap-1">
                                <MapPin className="h-3 w-3 text-success" />
                                <span className="truncate">{task.drop_address}</span>
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge variant={status.variant}>{status.label}</Badge>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
