import { useState } from "react";
import { CustomerSidebar } from "@/components/layout/CustomerSidebar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  MapPin, 
  Clock, 
  DollarSign,
  ArrowRight,
  Package,
  ShoppingCart,
  Truck,
  Wrench,
  Sparkles,
  FileText,
  CheckCircle
} from "lucide-react";
import { cn } from "@/lib/utils";

const categories = [
  { id: "delivery", name: "Delivery", icon: Package, description: "Pickup & drop items" },
  { id: "shopping", name: "Shopping", icon: ShoppingCart, description: "Grocery & retail" },
  { id: "moving", name: "Moving", icon: Truck, description: "Help with moving" },
  { id: "assembly", name: "Assembly", icon: Wrench, description: "Furniture assembly" },
  { id: "cleaning", name: "Cleaning", icon: Sparkles, description: "Home cleaning" },
  { id: "errands", name: "Errands", icon: FileText, description: "Various errands" }
];

export default function NewTask() {
  const [step, setStep] = useState(1);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    pickupAddress: "",
    dropAddress: "",
    scheduledTime: ""
  });

  const estimatedPrice = selectedCategory ? Math.floor(Math.random() * 300) + 100 : 0;

  return (
    <div className="min-h-screen bg-background">
      <CustomerSidebar />
      
      <main className="lg:pl-64">
        <div className="p-4 lg:p-8 pt-20 lg:pt-8 max-w-4xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-2xl md:text-3xl font-bold">Create New Task</h1>
            <p className="text-muted-foreground">Fill in the details to get matched with a helper</p>
          </div>

          {/* Progress Steps */}
          <div className="flex items-center gap-4 mb-8">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center gap-2">
                <div className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold transition-colors",
                  step >= s 
                    ? "bg-primary text-primary-foreground" 
                    : "bg-secondary text-muted-foreground"
                )}>
                  {step > s ? <CheckCircle className="h-4 w-4" /> : s}
                </div>
                <span className={cn(
                  "text-sm font-medium hidden sm:block",
                  step >= s ? "text-foreground" : "text-muted-foreground"
                )}>
                  {s === 1 ? "Category" : s === 2 ? "Details" : "Review"}
                </span>
                {s < 3 && <div className="w-8 h-px bg-border" />}
              </div>
            ))}
          </div>

          {/* Step 1: Category Selection */}
          {step === 1 && (
            <Card>
              <CardHeader>
                <CardTitle>Select Task Category</CardTitle>
                <CardDescription>Choose the type of help you need</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {categories.map((category) => (
                    <button
                      key={category.id}
                      onClick={() => setSelectedCategory(category.id)}
                      className={cn(
                        "flex flex-col items-center gap-3 p-6 rounded-xl border-2 transition-all duration-300",
                        selectedCategory === category.id
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-muted-foreground"
                      )}
                    >
                      <div className={cn(
                        "w-14 h-14 rounded-2xl flex items-center justify-center transition-colors",
                        selectedCategory === category.id 
                          ? "bg-primary text-primary-foreground" 
                          : "bg-secondary text-muted-foreground"
                      )}>
                        <category.icon className="h-7 w-7" />
                      </div>
                      <div className="text-center">
                        <div className="font-semibold">{category.name}</div>
                        <div className="text-xs text-muted-foreground">{category.description}</div>
                      </div>
                    </button>
                  ))}
                </div>

                <div className="flex justify-end mt-8">
                  <Button 
                    variant="hero" 
                    disabled={!selectedCategory}
                    onClick={() => setStep(2)}
                  >
                    Continue
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 2: Task Details */}
          {step === 2 && (
            <Card>
              <CardHeader>
                <CardTitle>Task Details</CardTitle>
                <CardDescription>Provide information about your task</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Task Title</label>
                  <Input
                    placeholder="e.g., Grocery pickup from BigBazaar"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Description</label>
                  <textarea
                    className="flex min-h-[100px] w-full rounded-lg border border-border bg-secondary/50 px-4 py-3 text-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50 focus-visible:border-primary"
                    placeholder="Describe what you need help with..."
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-primary" />
                      Pickup Location
                    </label>
                    <Input
                      placeholder="Enter pickup address"
                      value={formData.pickupAddress}
                      onChange={(e) => setFormData({ ...formData, pickupAddress: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-success" />
                      Drop Location
                    </label>
                    <Input
                      placeholder="Enter drop address"
                      value={formData.dropAddress}
                      onChange={(e) => setFormData({ ...formData, dropAddress: e.target.value })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Clock className="h-4 w-4 text-warning" />
                    Preferred Time
                  </label>
                  <Input
                    type="datetime-local"
                    value={formData.scheduledTime}
                    onChange={(e) => setFormData({ ...formData, scheduledTime: e.target.value })}
                  />
                </div>

                <div className="flex justify-between mt-8">
                  <Button variant="outline" onClick={() => setStep(1)}>
                    Back
                  </Button>
                  <Button 
                    variant="hero"
                    onClick={() => setStep(3)}
                    disabled={!formData.title || !formData.pickupAddress}
                  >
                    Continue
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 3: Review & Submit */}
          {step === 3 && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Review Your Task</CardTitle>
                  <CardDescription>Confirm the details before posting</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="p-4 rounded-xl bg-secondary/30 border border-border/50">
                    <div className="flex items-center gap-3 mb-4">
                      <Badge variant="glow">{categories.find(c => c.id === selectedCategory)?.name}</Badge>
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{formData.title || "Untitled Task"}</h3>
                    <p className="text-muted-foreground">{formData.description || "No description provided"}</p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-4 rounded-xl bg-secondary/30 border border-border/50">
                      <div className="flex items-center gap-2 text-primary mb-2">
                        <MapPin className="h-4 w-4" />
                        <span className="text-sm font-medium">Pickup</span>
                      </div>
                      <p className="text-sm">{formData.pickupAddress || "Not specified"}</p>
                    </div>
                    <div className="p-4 rounded-xl bg-secondary/30 border border-border/50">
                      <div className="flex items-center gap-2 text-success mb-2">
                        <MapPin className="h-4 w-4" />
                        <span className="text-sm font-medium">Drop</span>
                      </div>
                      <p className="text-sm">{formData.dropAddress || "Not specified"}</p>
                    </div>
                  </div>

                  {formData.scheduledTime && (
                    <div className="p-4 rounded-xl bg-secondary/30 border border-border/50">
                      <div className="flex items-center gap-2 text-warning mb-2">
                        <Clock className="h-4 w-4" />
                        <span className="text-sm font-medium">Scheduled Time</span>
                      </div>
                      <p className="text-sm">{new Date(formData.scheduledTime).toLocaleString()}</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Price Estimate */}
              <Card className="border-primary/50 bg-primary/5">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                        <DollarSign className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Estimated Price</div>
                        <div className="text-2xl font-bold">₹{estimatedPrice}</div>
                      </div>
                    </div>
                    <Badge variant="glow">Best Price</Badge>
                  </div>
                </CardContent>
              </Card>

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(2)}>
                  Back
                </Button>
                <Button variant="hero" size="lg">
                  Post Task
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
