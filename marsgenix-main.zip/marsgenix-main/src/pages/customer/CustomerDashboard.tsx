import { CustomerSidebar } from "@/components/layout/CustomerSidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Plus, 
  Clock, 
  CheckCircle, 
  MapPin, 
  ArrowRight,
  Package,
  Truck,
  AlertCircle
} from "lucide-react";
import { Link } from "react-router-dom";

const recentTasks = [
  {
    id: "1",
    title: "Grocery Pickup & Delivery",
    status: "in_progress",
    helper: "Rahul S.",
    category: "Delivery",
    createdAt: "2 hours ago"
  },
  {
    id: "2",
    title: "Document Collection",
    status: "completed",
    helper: "Priya M.",
    category: "Errands",
    createdAt: "Yesterday"
  },
  {
    id: "3",
    title: "Furniture Assembly",
    status: "pending",
    helper: null,
    category: "Assembly",
    createdAt: "3 hours ago"
  }
];

const statusConfig = {
  pending: { label: "Pending", variant: "warning" as const, icon: Clock },
  in_progress: { label: "In Progress", variant: "glow" as const, icon: Truck },
  completed: { label: "Completed", variant: "success" as const, icon: CheckCircle }
};

export default function CustomerDashboard() {
  return (
    <div className="min-h-screen bg-background">
      <CustomerSidebar />
      
      <main className="lg:pl-64">
        <div className="p-4 lg:p-8 pt-20 lg:pt-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">Welcome back, John!</h1>
              <p className="text-muted-foreground">Here's what's happening with your tasks</p>
            </div>
            <Button variant="hero" asChild>
              <Link to="/customer/new-task">
                <Plus className="h-4 w-4 mr-2" />
                Create New Task
              </Link>
            </Button>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card className="hover:border-primary/50 transition-colors">
              <CardContent className="p-4 lg:p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Active Tasks</p>
                    <p className="text-2xl lg:text-3xl font-bold">3</p>
                  </div>
                  <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Clock className="h-5 w-5 lg:h-6 lg:w-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:border-success/50 transition-colors">
              <CardContent className="p-4 lg:p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Completed</p>
                    <p className="text-2xl lg:text-3xl font-bold">12</p>
                  </div>
                  <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-success/10 flex items-center justify-center">
                    <CheckCircle className="h-5 w-5 lg:h-6 lg:w-6 text-success" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:border-warning/50 transition-colors">
              <CardContent className="p-4 lg:p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Pending</p>
                    <p className="text-2xl lg:text-3xl font-bold">1</p>
                  </div>
                  <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-warning/10 flex items-center justify-center">
                    <AlertCircle className="h-5 w-5 lg:h-6 lg:w-6 text-warning" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:border-primary/50 transition-colors">
              <CardContent className="p-4 lg:p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Spent</p>
                    <p className="text-2xl lg:text-3xl font-bold">₹4,520</p>
                  </div>
                  <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Package className="h-5 w-5 lg:h-6 lg:w-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Tasks */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Recent Tasks</CardTitle>
              <Button variant="ghost" asChild>
                <Link to="/customer/tasks" className="text-sm">
                  View all
                  <ArrowRight className="h-4 w-4 ml-1" />
                </Link>
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentTasks.map((task) => {
                  const status = statusConfig[task.status as keyof typeof statusConfig];
                  const StatusIcon = status.icon;
                  
                  return (
                    <div 
                      key={task.id}
                      className="flex flex-col md:flex-row md:items-center justify-between p-4 rounded-xl bg-secondary/30 border border-border/50 hover:border-primary/30 transition-colors gap-4"
                    >
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <StatusIcon className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-medium">{task.title}</h3>
                          <div className="flex flex-wrap items-center gap-2 mt-1 text-sm text-muted-foreground">
                            <span>{task.category}</span>
                            <span>•</span>
                            <span>{task.createdAt}</span>
                            {task.helper && (
                              <>
                                <span>•</span>
                                <span className="flex items-center gap-1">
                                  <MapPin className="h-3 w-3" />
                                  {task.helper}
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                      <Badge variant={status.variant}>{status.label}</Badge>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <div className="grid md:grid-cols-2 gap-4 mt-8">
            <Card className="group hover:border-primary/50 transition-all cursor-pointer">
              <CardContent className="p-6">
                <Link to="/customer/new-task" className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-cyan-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Package className="h-7 w-7 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Delivery Task</h3>
                    <p className="text-sm text-muted-foreground">Pick up and deliver items</p>
                  </div>
                  <ArrowRight className="h-5 w-5 ml-auto text-muted-foreground group-hover:text-primary transition-colors" />
                </Link>
              </CardContent>
            </Card>

            <Card className="group hover:border-primary/50 transition-all cursor-pointer">
              <CardContent className="p-6">
                <Link to="/customer/new-task" className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-cyan-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Truck className="h-7 w-7 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Errand Task</h3>
                    <p className="text-sm text-muted-foreground">Get help with daily errands</p>
                  </div>
                  <ArrowRight className="h-5 w-5 ml-auto text-muted-foreground group-hover:text-primary transition-colors" />
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
