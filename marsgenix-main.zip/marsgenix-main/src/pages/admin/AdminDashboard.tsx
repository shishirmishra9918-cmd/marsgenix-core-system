import { AdminSidebar } from "@/components/layout/AdminSidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  UserCheck, 
  ClipboardList, 
  DollarSign,
  TrendingUp,
  ArrowRight,
  AlertCircle,
  CheckCircle,
  Clock
} from "lucide-react";
import { Link } from "react-router-dom";

const pendingApprovals = [
  { id: "1", name: "Vikram Singh", submitted: "2 hours ago", documents: 3 },
  { id: "2", name: "Priya Sharma", submitted: "5 hours ago", documents: 3 },
  { id: "3", name: "Ankit Patel", submitted: "1 day ago", documents: 2 }
];

const recentTasks = [
  { id: "1", title: "Grocery Delivery", status: "completed", amount: 150 },
  { id: "2", title: "Document Pickup", status: "in_progress", amount: 100 },
  { id: "3", title: "Medicine Delivery", status: "pending", amount: 180 }
];

export default function AdminDashboard() {
  return (
    <div className="min-h-screen bg-background">
      <AdminSidebar />
      
      <main className="lg:pl-64">
        <div className="p-4 lg:p-8 pt-20 lg:pt-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-2xl md:text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground">Platform overview and management</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card className="hover:border-primary/50 transition-colors">
              <CardContent className="p-4 lg:p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Users</p>
                    <p className="text-2xl lg:text-3xl font-bold">12,450</p>
                    <p className="text-xs text-success flex items-center gap-1 mt-1">
                      <TrendingUp className="h-3 w-3" />
                      +8.5%
                    </p>
                  </div>
                  <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Users className="h-5 w-5 lg:h-6 lg:w-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:border-success/50 transition-colors">
              <CardContent className="p-4 lg:p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Active Helpers</p>
                    <p className="text-2xl lg:text-3xl font-bold">1,280</p>
                    <p className="text-xs text-success flex items-center gap-1 mt-1">
                      <TrendingUp className="h-3 w-3" />
                      +12%
                    </p>
                  </div>
                  <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-success/10 flex items-center justify-center">
                    <UserCheck className="h-5 w-5 lg:h-6 lg:w-6 text-success" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:border-warning/50 transition-colors">
              <CardContent className="p-4 lg:p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Tasks Today</p>
                    <p className="text-2xl lg:text-3xl font-bold">486</p>
                    <p className="text-xs text-success flex items-center gap-1 mt-1">
                      <TrendingUp className="h-3 w-3" />
                      +5.2%
                    </p>
                  </div>
                  <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-warning/10 flex items-center justify-center">
                    <ClipboardList className="h-5 w-5 lg:h-6 lg:w-6 text-warning" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:border-primary/50 transition-colors">
              <CardContent className="p-4 lg:p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Revenue Today</p>
                    <p className="text-2xl lg:text-3xl font-bold">₹72,840</p>
                    <p className="text-xs text-success flex items-center gap-1 mt-1">
                      <TrendingUp className="h-3 w-3" />
                      +15%
                    </p>
                  </div>
                  <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <DollarSign className="h-5 w-5 lg:h-6 lg:w-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid lg:grid-cols-2 gap-6 mb-8">
            {/* Pending Approvals */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div className="flex items-center gap-2">
                  <CardTitle>Pending Approvals</CardTitle>
                  <Badge variant="warning">{pendingApprovals.length}</Badge>
                </div>
                <Button variant="ghost" asChild>
                  <Link to="/admin/approvals">
                    View all
                    <ArrowRight className="h-4 w-4 ml-1" />
                  </Link>
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {pendingApprovals.map((helper) => (
                    <div 
                      key={helper.id}
                      className="flex items-center justify-between p-4 rounded-xl bg-secondary/30 border border-border/50"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                          <span className="font-semibold text-primary">
                            {helper.name.charAt(0)}
                          </span>
                        </div>
                        <div>
                          <div className="font-medium">{helper.name}</div>
                          <div className="text-sm text-muted-foreground">
                            {helper.documents} documents • {helper.submitted}
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline">
                          Review
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Tasks */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Recent Tasks</CardTitle>
                <Button variant="ghost" asChild>
                  <Link to="/admin/tasks">
                    View all
                    <ArrowRight className="h-4 w-4 ml-1" />
                  </Link>
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentTasks.map((task) => {
                    const statusConfig = {
                      pending: { label: "Pending", variant: "warning" as const, icon: Clock },
                      in_progress: { label: "In Progress", variant: "glow" as const, icon: AlertCircle },
                      completed: { label: "Completed", variant: "success" as const, icon: CheckCircle }
                    };
                    const status = statusConfig[task.status as keyof typeof statusConfig];
                    
                    return (
                      <div 
                        key={task.id}
                        className="flex items-center justify-between p-4 rounded-xl bg-secondary/30 border border-border/50"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                            <status.icon className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <div className="font-medium">{task.title}</div>
                            <div className="text-sm text-muted-foreground">₹{task.amount}</div>
                          </div>
                        </div>
                        <Badge variant={status.variant}>{status.label}</Badge>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Stats */}
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="bg-gradient-to-br from-primary/10 to-cyan-500/10 border-primary/30">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-primary/20 flex items-center justify-center">
                    <Users className="h-7 w-7 text-primary" />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">New Signups Today</div>
                    <div className="text-2xl font-bold">+124</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-success/10 to-green-500/10 border-success/30">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-success/20 flex items-center justify-center">
                    <CheckCircle className="h-7 w-7 text-success" />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Tasks Completed</div>
                    <div className="text-2xl font-bold">312</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-warning/10 to-orange-500/10 border-warning/30">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-warning/20 flex items-center justify-center">
                    <AlertCircle className="h-7 w-7 text-warning" />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Pending Issues</div>
                    <div className="text-2xl font-bold">8</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
