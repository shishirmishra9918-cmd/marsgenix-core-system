import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export interface Task {
  id: string;
  customer_id: string;
  helper_id: string | null;
  category_id: string | null;
  title: string;
  description: string | null;
  status: string;
  pickup_address: string;
  pickup_lat: number | null;
  pickup_lng: number | null;
  drop_address: string;
  drop_lat: number | null;
  drop_lng: number | null;
  distance_km: number | null;
  estimated_price: number | null;
  final_price: number | null;
  scheduled_at: string | null;
  accepted_at: string | null;
  picked_up_at: string | null;
  delivered_at: string | null;
  completed_at: string | null;
  cancelled_at: string | null;
  cancel_reason: string | null;
  customer_rating: number | null;
  helper_rating: number | null;
  customer_review: string | null;
  helper_review: string | null;
  created_at: string;
  updated_at: string;
  task_categories?: {
    name: string;
    icon: string;
  };
  profiles?: {
    full_name: string;
    email: string;
  };
}

export function useTasks() {
  const { user, role } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchTasks = async () => {
    if (!user) return;

    setIsLoading(true);
    try {
      let query = supabase
        .from("tasks")
        .select(`
          *,
          task_categories (name, icon)
        `)
        .order("created_at", { ascending: false });

      const { data, error } = await query;

      if (error) throw error;
      setTasks(data || []);
    } catch (error: any) {
      console.error("Error fetching tasks:", error);
      toast.error("Failed to load tasks");
    } finally {
      setIsLoading(false);
    }
  };

  const createTask = async (taskData: {
    title: string;
    description?: string;
    category_id: string;
    pickup_address: string;
    drop_address: string;
    scheduled_at?: string;
    estimated_price?: number;
    distance_km?: number;
  }) => {
    if (!user) return { error: "Not authenticated" };

    try {
      const { data, error } = await supabase
        .from("tasks")
        .insert({
          ...taskData,
          customer_id: user.id,
          status: "pending",
        })
        .select()
        .single();

      if (error) throw error;

      toast.success("Task created successfully!");
      fetchTasks();
      return { data, error: null };
    } catch (error: any) {
      toast.error(error.message || "Failed to create task");
      return { data: null, error };
    }
  };

  const acceptTask = async (taskId: string) => {
    if (!user) return { error: "Not authenticated" };

    try {
      const { error } = await supabase
        .from("tasks")
        .update({
          helper_id: user.id,
          status: "accepted",
          accepted_at: new Date().toISOString(),
        })
        .eq("id", taskId);

      if (error) throw error;

      toast.success("Task accepted!");
      fetchTasks();
      return { error: null };
    } catch (error: any) {
      toast.error(error.message || "Failed to accept task");
      return { error };
    }
  };

  const updateTaskStatus = async (taskId: string, status: string) => {
    try {
      const updates: any = { status };

      if (status === "in_progress") {
        updates.picked_up_at = new Date().toISOString();
      } else if (status === "delivered") {
        updates.delivered_at = new Date().toISOString();
      } else if (status === "completed") {
        updates.completed_at = new Date().toISOString();
      } else if (status === "cancelled") {
        updates.cancelled_at = new Date().toISOString();
      }

      const { error } = await supabase
        .from("tasks")
        .update(updates)
        .eq("id", taskId);

      if (error) throw error;

      toast.success(`Task ${status.replace("_", " ")}!`);
      fetchTasks();
      return { error: null };
    } catch (error: any) {
      toast.error(error.message || "Failed to update task");
      return { error };
    }
  };

  const cancelTask = async (taskId: string, reason: string) => {
    try {
      const { error } = await supabase
        .from("tasks")
        .update({
          status: "cancelled",
          cancelled_at: new Date().toISOString(),
          cancel_reason: reason,
        })
        .eq("id", taskId);

      if (error) throw error;

      toast.success("Task cancelled");
      fetchTasks();
      return { error: null };
    } catch (error: any) {
      toast.error(error.message || "Failed to cancel task");
      return { error };
    }
  };

  useEffect(() => {
    fetchTasks();

    // Subscribe to realtime updates
    const channel = supabase
      .channel("tasks-changes")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "tasks" },
        () => {
          fetchTasks();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  return {
    tasks,
    isLoading,
    fetchTasks,
    createTask,
    acceptTask,
    updateTaskStatus,
    cancelTask,
  };
}
