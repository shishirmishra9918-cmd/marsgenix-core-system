import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface PricingRule {
  id: string;
  category_id: string | null;
  name: string;
  price_per_km: number;
  base_price: number;
  surge_multiplier: number;
  is_active: boolean;
}

export function usePricing() {
  const [pricingRules, setPricingRules] = useState<PricingRule[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchPricingRules = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from("pricing_rules")
        .select("*")
        .eq("is_active", true);

      if (error) throw error;
      setPricingRules(data || []);
    } catch (error) {
      console.error("Error fetching pricing rules:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const calculatePrice = (distanceKm: number, categoryId?: string) => {
    // Find category-specific rule or use default
    const rule = pricingRules.find(
      (r) => r.category_id === categoryId || !r.category_id
    ) || {
      base_price: 50,
      price_per_km: 5,
      surge_multiplier: 1,
    };

    const baseAmount = Number(rule.base_price);
    const distanceAmount = distanceKm * Number(rule.price_per_km);
    const total = (baseAmount + distanceAmount) * Number(rule.surge_multiplier);

    return Math.round(total);
  };

  useEffect(() => {
    fetchPricingRules();
  }, []);

  return { pricingRules, isLoading, calculatePrice, fetchPricingRules };
}
